(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_material_esm_7e00b6d2._.js",
  "static/chunks/node_modules_44282e11._.js",
  "static/chunks/src_app_auth_login_page_8765143c.js"
],
    source: "dynamic"
});
