(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_cd5e70f9._.js",
  "static/chunks/node_modules_@apollo_client_be728f99._.js",
  "static/chunks/node_modules_@mui_system_esm_1805e4a8._.js",
  "static/chunks/node_modules_@mui_material_esm_15979d0f._.js",
  "static/chunks/node_modules_71a539f3._.js",
  "static/chunks/src_1de56706._.js"
],
    source: "dynamic"
});
