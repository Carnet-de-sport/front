__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__e2c08166._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_a51498a5._.js",
  "static/chunks/[root-of-the-server]__49fd8634._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_9114105e._.js"
])
