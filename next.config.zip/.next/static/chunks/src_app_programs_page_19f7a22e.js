(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c9d0299b._.js",
  "static/chunks/src_68e5d02d._.js"
],
    source: "dynamic"
});
