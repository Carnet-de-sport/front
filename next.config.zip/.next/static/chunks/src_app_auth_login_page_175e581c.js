(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_system_esm_8d91d2e0._.js",
  "static/chunks/node_modules_@mui_material_esm_85b4723f._.js",
  "static/chunks/node_modules_f553b264._.js",
  "static/chunks/src_app_auth_login_page_8765143c.js"
],
    source: "dynamic"
});
