(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b955a7c8._.js",
  "static/chunks/src_app_page_49c0cc01.js"
],
    source: "dynamic"
});
